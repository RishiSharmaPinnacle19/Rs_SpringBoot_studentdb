package com.pinnacle.student.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.pinnacle.student.model.Student;
import com.pinnacle.student.service.IStudentService;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private IStudentService service;

    // Display the home page with a list of all students
    @GetMapping("/")
    public String showHomePage(Model model) {
        List<Student> students = service.getAllStudents();
        model.addAttribute("students", students);
        return "homePage"; // Thymeleaf template name for home page
    }

    // Show the registration form for adding a new student
    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("student", new Student());
        return "registerStudent"; // Thymeleaf template for registration
    }

    // Save a new student to the database
    @PostMapping("/save")
    public String saveStudent(@ModelAttribute Student student, RedirectAttributes redirectAttributes) {
        try {
            service.saveStudent(student);
            redirectAttributes.addFlashAttribute("message", "Student added successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to add student: " + e.getMessage());
        }
        return "redirect:/students/";
    }

    // Sort students based on the given criteria
    @GetMapping("/sort")
    public String sortStudents(@RequestParam String sortBy, Model model) {
        List<Student> sortedStudents;

        switch (sortBy) {
            case "course":
                sortedStudents = service.getAllStudentsSortedByCourse();
                break;
            case "balanceFees":
                sortedStudents = service.getAllStudentsSortedByBalanceFees();
                break;
            case "courseBalance":
                sortedStudents = service.getAllStudentsSortedByCourseAndBalanceFees();
                break;
            default:
                sortedStudents = service.getAllStudents();
                break;
        }

        model.addAttribute("students", sortedStudents);
        return "homePage";
    }

    // Show the edit form for a specific student
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        try {
            Student student = service.getStudentById(id);
            if (student == null) {
                redirectAttributes.addFlashAttribute("error", "Student not found!");
                return "redirect:/students/";
            }
            model.addAttribute("student", student);
            return "editStudent"; // Thymeleaf template for editing
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error fetching student details: " + e.getMessage());
            return "redirect:/students/";
        }
    }

    // Update an existing student
    @PostMapping("/update")
    public String updateStudent(@ModelAttribute Student student, RedirectAttributes redirectAttributes) {
        try {
            service.updateStudent(student);
            redirectAttributes.addFlashAttribute("message", "Student updated successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to update student: " + e.getMessage());
        }
        return "redirect:/students/";
    }

    // Delete a student by ID
    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            service.deleteStudentById(id);
            redirectAttributes.addFlashAttribute("message", "Student deleted successfully!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Failed to delete student: " + e.getMessage());
        }
        return "redirect:/students/";
    }
}
