package com.pinnacle.student.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Student {
    
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String college;
    private String address;
    private String contactNo;
    private String course;
    private Double fees;
    private Double paidFees;

    // Default constructor
    public Student() {
    }

    // Parameterized constructor
    public Student(Long id, String name, String college, String address, String contactNo, 
                   String course, Double fees, Double paidFees) {
        this.id = id;
        this.name = name;
        this.college = college;
        this.address = address;
        this.contactNo = contactNo;
        this.course = course;
        this.fees = fees;
        this.paidFees = paidFees;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public Double getFees() {
        return fees;
    }

    public void setFees(Double fees) {
        this.fees = fees;
    }

    public Double getPaidFees() {
        return paidFees;
    }

    public void setPaidFees(Double paidFees) {
        this.paidFees = paidFees;
    }

    // Method to calculate balance fees
    public Double getBalanceFees() {
        return fees - paidFees; // Returns the balance fees
    }
}
