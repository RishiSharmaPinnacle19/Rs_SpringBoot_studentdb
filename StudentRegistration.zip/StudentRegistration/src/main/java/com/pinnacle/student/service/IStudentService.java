package com.pinnacle.student.service;

import java.util.List;

import com.pinnacle.student.model.Student;

public interface IStudentService {
    Student saveStudent(Student student);
    List<Student> getAllStudents();
    List<Student> getAllStudentsSortedByCourse();
    List<Student> getAllStudentsSortedByBalanceFees();
    List<Student> getAllStudentsSortedByCourseAndBalanceFees();
    Student getStudentById(Long id);
    void deleteStudentById(Long id);
    void updateStudent(Student student);
}
