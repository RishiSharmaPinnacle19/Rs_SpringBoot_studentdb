package com.pinnacle.student.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.pinnacle.student.model.Student;
import com.pinnacle.student.repository.StudentRepository;

@Service
public class StudentServiceImpl implements IStudentService {

    @Autowired
    private StudentRepository repo;

    @Override
    public Student saveStudent(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student object cannot be null");
        }
        return repo.save(student);
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = repo.findAll();
        if (students.isEmpty()) {
            throw new RuntimeException("No students found");
        }
        return students;
    }

    @Override
    public List<Student> getAllStudentsSortedByCourse() {
        return repo.findAll(Sort.by(Sort.Order.asc("course")));
    }

    @Override
    public List<Student> getAllStudentsSortedByBalanceFees() {
        return repo.findAll(Sort.by(Sort.Order.asc("fees"), Sort.Order.asc("paidFees")));
    }

    @Override
    public List<Student> getAllStudentsSortedByCourseAndBalanceFees() {
        return repo.findAll(Sort.by(Sort.Order.asc("course"), Sort.Order.asc("fees")));
    }

    @Override
    public Student getStudentById(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Invalid student ID");
        }
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Student with ID " + id + " not found"));
    }

    @Override
    public void deleteStudentById(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("Invalid student ID");
        }
        if (!repo.existsById(id)) {
            throw new RuntimeException("Cannot delete student. Student with ID " + id + " does not exist");
        }
        repo.deleteById(id);
    }

    @Override
    public void updateStudent(Student student) {
        if (student == null || student.getId() == null) {
            throw new IllegalArgumentException("Student or Student ID cannot be null");
        }
        Optional<Student> existingStudent = repo.findById(student.getId());
        if (existingStudent.isEmpty()) {
            throw new RuntimeException("Cannot update. Student with ID " + student.getId() + " does not exist");
        }
        repo.save(student);
    }
}
